# Gate 2 — Entrega local e bloqueios técnicos

Fonte: `Evandro-J-O-Andrade/SistemaCadastroMedicos` em `3115219`.

## Arquivos desta entrega
- `src/auth/AuthProvider.tsx`: um único estado Supabase Auth + bootstrap confiável, fail closed.
- `src/auth/AccessGuard.tsx`: rotas protegidas por etapa de onboarding, papel e permissão.
- `src/pages/WelcomeEnterprise.tsx`: welcome real por nome e módulos autorizados.
- `src/pages/EnterpriseBlocked.tsx`: explicação amigável quando servidor não autoriza.
- `src/styles/enterprise.css`: base visual Enterprise.

## Integração necessária
1. O ROOT/usuário deve ser provisionado por processo administrativo auditado.
2. Implementar e homologar **antes de habilitar login produtivo** a RPC `fn_auth_bootstrap_v2()` que retorna JSON com:
   `person_id`, `full_name`, `email`, `roles[]`, `permissions[]`, `memberships[]`,
   `must_change_password`, `terms_pending`, `responsibility_pending`, `welcome_pending`.
   A RPC deve derivar identidade de `auth.uid()` sem argumentos manipuláveis e consultar vínculos ativos e permissões efetivas no PostgreSQL. Não implementar permissões como `true` por default.
3. Implementar eventos auditáveis que avancem password/terms/responsibility/welcome no banco: **não** usar localStorage ou user_metadata editável como comprovação de senha alterada/aceites. Mudança de senha requer verificação confiável do evento Auth do lado servidor; termos requerem documento/versionamento/aceite gravado no banco.
4. Corrigir Gate 1 antes do deploy: `fn_set_session_contexto` atualmente aceita `p_auth_user_id` não verificado e usa `set_config(..., true)` transacional: não se deve depender disso em requisições PostgREST posteriores. `fn_person_has_permission` tem risco de associação/escopo indevido em condições `OR` e deve ser auditada. RLS de `audit_events` aceita qualquer inserção autenticada: remover inserção livre, registrar exclusivamente por função/trigger confiável.
5. Corrigir incompatibilidade entre `src/types/database.ts` e migrations Gate 1 antes de gerar tipos reais.
6. Migrar páginas antigas para hooks do Provider, sem manter estados paralelos em `App.tsx`.
7. CRUD de usuário deve usar backend administrativo, não `supabase.auth.signUp` diretamente do navegador.

## Exemplo de wiring (NÃO aplicar cegamente)

```tsx
// main.tsx: <BrowserRouter><AuthProvider><App/></AuthProvider></BrowserRouter>
// Router: <Route element={<AccessGuard permission="medicos.read"/>}><Route path="/medicos" element={<Medicos/>}/></Route>
// Welcome: <Route path="/welcome" element={<WelcomeEnterprise/>}/>
// Deny: <Route path="/acesso-bloqueado" element={<EnterpriseBlocked/>}/>
```

A tela Welcome é um componente pronto, mas só deve ser aberta depois de o servidor confirmar que onboarding foi concluído. Nenhuma migration, conta ou alteração remota foi executada. Commit/push não autorizados nesta etapa.
