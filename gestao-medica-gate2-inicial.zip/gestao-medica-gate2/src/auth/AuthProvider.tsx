import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

/** API contract: fn_auth_bootstrap_v2, server-side SECURITY DEFINER using auth.uid(). */
export type RoleName = 'root' | 'admin' | 'gestor' | 'operador_ti' | 'suporte' | 'auditor';
export type AccessPhase = 'login' | 'blocked' | 'password' | 'terms' | 'responsibility' | 'welcome' | 'ready';
export interface ContextMembership { tenant_id: string; tenant_nome: string; unit_ids: string[] }
export interface AuthIdentity {
  person_id: string;
  full_name: string;
  email: string;
  roles: RoleName[];
  permissions: string[];
  memberships: ContextMembership[];
  must_change_password: boolean;
  terms_pending: boolean;
  responsibility_pending: boolean;
  welcome_pending: boolean;
}
interface AuthContextValue {
  session: Session | null;
  user: AuthIdentity | null;
  loading: boolean;
  authenticated: boolean;
  phase: AccessPhase;
  error: string | null;
  signIn(email: string, password: string): Promise<void>;
  signOut(): Promise<void>;
  refresh(): Promise<void>;
  hasRole(role: RoleName): boolean;
  hasPermission(permission: string): boolean;
}
const AuthContext = createContext<AuthContextValue | null>(null);

function parseIdentity(input: unknown): AuthIdentity {
  if (!input || typeof input !== 'object') throw new Error('Contrato de identidade indisponível');
  const data = input as Record<string, unknown>;
  if (typeof data.person_id !== 'string' || !data.person_id || typeof data.full_name !== 'string') {
    throw new Error('Pessoa não vinculada à identidade autenticada');
  }
  const roles = Array.isArray(data.roles) ? data.roles.filter((v): v is RoleName =>
    ['root', 'admin', 'gestor', 'operador_ti', 'suporte', 'auditor'].includes(String(v))) : [];
  if (!roles.length) throw new Error('Conta sem papel ativo autorizado');
  if (!Array.isArray(data.permissions)) throw new Error('Permissões não fornecidas pelo servidor');
  const requiredFlags = ['must_change_password','terms_pending','responsibility_pending','welcome_pending'] as const;
  if (requiredFlags.some(flag => typeof data[flag] !== 'boolean')) throw new Error('Onboarding não validado pelo servidor');
  const memberships: ContextMembership[] = Array.isArray(data.memberships)
    ? data.memberships.filter((v): v is ContextMembership => !!v && typeof v === 'object' && typeof v.tenant_id === 'string' && Array.isArray(v.unit_ids))
    : [];
  return {
    person_id: data.person_id,
    full_name: data.full_name,
    email: typeof data.email === 'string' ? data.email : '',
    roles,
    permissions: data.permissions.filter((v): v is string => typeof v === 'string'),
    memberships,
    must_change_password: data.must_change_password as boolean,
    terms_pending: data.terms_pending as boolean,
    responsibility_pending: data.responsibility_pending as boolean,
    welcome_pending: data.welcome_pending as boolean,
  };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<AuthIdentity | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const resolve = useCallback(async (next: Session | null) => {
    if (!next) {
      setSession(null); setUser(null); setError(null); setLoading(false); return;
    }
    setLoading(true); setSession(next); setUser(null); setError(null);
    try {
      // IMPORTANT: never pass person_id / is_root / tenant_id from browser.
      // Backend authenticates via auth.uid() and checks active memberships/RBAC itself.
      const { data, error: rpcError } = await supabase.rpc('fn_auth_bootstrap_v2');
      if (rpcError) throw rpcError;
      setUser(parseIdentity(data));
    } catch {
      setError('Não foi possível validar identidade, permissões e primeiro acesso. Acesso bloqueado.');
      setUser(null); // fail-closed; do not fall back to role from user_metadata.
    } finally { setLoading(false); }
  }, []);

  useEffect(() => {
    let alive = true;
    void supabase.auth.getSession().then(({ data }) => {
      if (alive) void resolve(data.session);
    });
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, next) => {
      // Avoid awaiting a Supabase query in the synchronous auth callback.
      if (alive) void resolve(next);
    });
    return () => { alive = false; subscription.unsubscribe(); };
  }, [resolve]);

  const signIn = useCallback(async (email: string, password: string) => {
    const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });
    if (signInError) throw signInError;
    // onAuthStateChange invokes resolve; protected routes wait for resolution.
  }, []);
  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setSession(null); setUser(null); setError(null);
  }, []);
  const refresh = useCallback(async () => {
    const { data: { session: current } } = await supabase.auth.getSession();
    await resolve(current);
  }, [resolve]);
  const phase: AccessPhase = !session ? 'login' : !user ? 'blocked'
    : user.must_change_password ? 'password'
    : user.terms_pending ? 'terms'
    : user.responsibility_pending ? 'responsibility'
    : user.welcome_pending ? 'welcome' : 'ready';
  const ctx = useMemo<AuthContextValue>(() => ({
    session, user, loading, authenticated: !!session && !!user, phase, error,
    signIn, signOut, refresh,
    hasRole: role => !!user && user.roles.includes(role),
    hasPermission: permission => !!user && user.permissions.includes(permission),
  }), [session, user, loading, phase, error, signIn, signOut, refresh]);
  return <AuthContext.Provider value={ctx}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth requer AuthProvider');
  return context;
}
