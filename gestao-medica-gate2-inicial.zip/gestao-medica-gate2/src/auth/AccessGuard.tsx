import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth, type RoleName } from './AuthProvider';

export function AccessGuard({ roles, permission }: { roles?: RoleName[]; permission?: string }) {
  const auth = useAuth();
  const location = useLocation();
  if (auth.loading) return <div role="status" className="gm-loading">Validando sessão, vínculos e permissões…</div>;
  if (!auth.session) return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  if (auth.phase === 'blocked') return <Navigate to="/acesso-bloqueado" replace />;
  if (auth.phase === 'password') return <Navigate to="/primeiro-acesso/senha" replace />;
  if (auth.phase === 'terms') return <Navigate to="/primeiro-acesso/termos" replace />;
  if (auth.phase === 'responsibility') return <Navigate to="/primeiro-acesso/responsabilidade" replace />;
  if (auth.phase === 'welcome') return <Navigate to="/welcome" replace />;
  if (roles?.length && !roles.some(auth.hasRole)) return <Navigate to="/sem-permissao" replace />;
  if (permission && !auth.hasPermission(permission)) return <Navigate to="/sem-permissao" replace />;
  return <Outlet />;
}
