import { useNavigate } from 'react-router-dom';
import { Activity, ArrowRight, Building2, ShieldCheck, Stethoscope, Users } from 'lucide-react';
import { useAuth } from '../auth/AuthProvider';

/** No mock KPIs: only identity and actual authorized capabilities. */
export default function WelcomeEnterprise() {
  const auth = useAuth(); const navigate = useNavigate();
  if (!auth.user) return null;
  const firstName = auth.user.full_name.trim().split(/\s+/)[0];
  const modules = [
    { title: 'Central médica', description: 'Cadastros e vínculos profissionais', path: '/medicos', icon: Stethoscope, permission: 'medicos.read' },
    { title: 'Plantões 12×36', description: 'Produção médica e lotes ativos', path: '/plantao', icon: Activity, permission: 'producao.read' },
    { title: 'Relatórios', description: 'Indicadores, filtros e exportações', path: '/relatorios', icon: Building2, permission: 'relatorios.read' },
    { title: 'Gestão de usuários', description: 'Convites, papéis e auditoria', path: '/cadastro-usuarios', icon: Users, permission: 'users.manage' },
  ].filter(m => auth.hasPermission(m.permission));
  return <main className="gm-welcome">
    <div className="gm-welcome__hero">
      <div className="gm-eyebrow"><ShieldCheck size={18}/> Gestão Médica Alpha · Ambiente seguro</div>
      <h1>Bem-vindo à sua gestão médica, {firstName}.</h1>
      <p>Seu acesso foi identificado pelo núcleo People-First. Os módulos abaixo respeitam os vínculos e as permissões efetivas do seu perfil.</p>
      <div className="gm-chips">{auth.user.roles.map(r => <span key={r}>{r.toUpperCase()}</span>)}<span>{auth.user.memberships.length} organização(ões) vinculada(s)</span></div>
      <button className="gm-primary" onClick={() => navigate('/dashboard')}>Abrir central de comando <ArrowRight size={17}/></button>
    </div>
    <section aria-label="Módulos disponíveis"><div className="gm-section-heading"><h2>Seus módulos</h2><p>Somente recursos habilitados pelo backend.</p></div>
      <div className="gm-module-grid">{modules.map(({title,description,path,icon: Icon}) => <button className="gm-module" key={path} onClick={() => navigate(path)}><Icon size={24}/><strong>{title}</strong><span>{description}</span><ArrowRight size={17}/></button>)}</div>
      {!modules.length && <div className="gm-empty">Nenhum módulo operacional autorizado neste contexto. Solicite a um administrador a configuração das permissões.</div>}
    </section>
  </main>;
}
