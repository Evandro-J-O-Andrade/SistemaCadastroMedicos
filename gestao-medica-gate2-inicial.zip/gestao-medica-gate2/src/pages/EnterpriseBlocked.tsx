import { Link } from 'react-router-dom';
import { ShieldAlert } from 'lucide-react';
import { useAuth } from '../auth/AuthProvider';
export default function EnterpriseBlocked(){const auth=useAuth();return <main style={{maxWidth:650,margin:'12vh auto',padding:24,fontFamily:'system-ui'}}><ShieldAlert size={40}/><h1>Acesso pendente de validação</h1><p>{auth.error ?? 'Sua conta não possui autorização ou possui etapas de primeiro acesso pendentes.'}</p><p>Não é possível continuar sem validação de identidade e segurança no servidor.</p><button onClick={()=>void auth.refresh()}>Tentar novamente</button> <Link to="/login">Voltar ao login</Link></main>}
