\set ON_ERROR_STOP on
\pset pager off
\echo ===== GATE 2.4 / LOCAL READ-ONLY CHECKS =====
SELECT current_database() AS database_name, current_user AS login_role, version() AS server_version;
\echo ===== Expected tables =====
WITH expected(name) AS (
  VALUES ('people'),('auth_identity_links'),('tenants'),('units'),('tenant_settings'),
  ('tenant_memberships'),('unit_memberships'),('roles'),('permissions'),
  ('role_permissions'),('role_assignments'),('audit_events'),
  ('legal_documents'),('legal_acceptances'),('user_onboarding')
)
SELECT e.name AS table_name,
       CASE WHEN c.oid IS NULL THEN 'FAIL: MISSING' ELSE 'OK' END AS presence,
       COALESCE(c.relrowsecurity,false) AS rls_enabled,
       CASE WHEN c.oid IS NULL THEN 'N/A'
            WHEN c.relrowsecurity THEN 'OK'
            ELSE 'FAIL: RLS OFF' END AS rls_check
FROM expected e
LEFT JOIN pg_namespace n ON n.nspname='public'
LEFT JOIN pg_class c ON c.relnamespace=n.oid AND c.relname=e.name AND c.relkind IN ('r','p')
ORDER BY e.name;
\echo ===== Audit INSERT policies (all applicable policies, including ALL) =====
SELECT p.policyname, p.cmd, p.permissive, p.roles, p.with_check,
  CASE WHEN p.cmd IN ('INSERT','ALL') THEN 'REVIEW' ELSE 'not insert' END AS note
FROM pg_policies p
WHERE p.schemaname='public' AND p.tablename='audit_events'
ORDER BY p.policyname;
\echo ===== Effective audit INSERT privileges =====
SELECT r.role_name,
       has_table_privilege(r.role_name, 'public.audit_events', 'INSERT') AS can_insert,
       has_table_privilege(r.role_name, 'public.audit_events', 'UPDATE') AS can_update,
       has_table_privilege(r.role_name, 'public.audit_events', 'DELETE') AS can_delete
FROM (VALUES ('anon'),('authenticated')) r(role_name)
WHERE EXISTS (SELECT 1 FROM pg_roles WHERE rolname=r.role_name);
\echo ===== Exposed schema CREATE privileges =====
SELECT r.role_name, has_schema_privilege(r.role_name,'public','CREATE') AS can_create_in_public
FROM (VALUES ('anon'),('authenticated')) r(role_name)
WHERE EXISTS (SELECT 1 FROM pg_roles WHERE rolname=r.role_name);
\echo ===== Key authorization functions =====
WITH f(name) AS (VALUES ('fn_auth_bootstrap_v2'),('fn_resolve_person_id'),('fn_is_root'),
 ('fn_person_has_permission'),('fn_admin_register_person'),('fn_accept_legal_document'),
 ('fn_mark_password_changed'),('fn_confirm_password_changed_by_auth_user'),
 ('fn_audit_log'),('trg_audit_event'),('fn_onboarding_status'))
SELECT f.name, COALESCE(p.oid IS NOT NULL,false) AS exists,
       p.prosecdef AS security_definer, p.provolatile AS volatility,
       pg_get_function_identity_arguments(p.oid) AS signature,
       p.proconfig AS function_config
FROM f LEFT JOIN pg_namespace n ON n.nspname='public'
LEFT JOIN pg_proc p ON p.pronamespace=n.oid AND p.proname=f.name
ORDER BY f.name;
\echo ===== Legacy permissive audit policy must not exist =====
SELECT CASE WHEN EXISTS (
 SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='audit_events'
 AND policyname='audit_system_insert'
) THEN 'FAIL: audit_system_insert exists' ELSE 'OK: removed' END AS result;
\echo ===== Core RLS policy inventory =====
SELECT tablename, cmd, count(*) AS policies
FROM pg_policies WHERE schemaname='public'
AND tablename IN ('people','auth_identity_links','tenants','units','tenant_memberships',
 'unit_memberships','roles','permissions','role_permissions','role_assignments','audit_events',
 'legal_documents','legal_acceptances','user_onboarding')
GROUP BY tablename,cmd ORDER BY tablename,cmd;
\echo ===== READ ONLY FINISHED =====
