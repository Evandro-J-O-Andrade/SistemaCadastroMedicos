param(
  [string]$Workspace = 'D:\SistemaCadastroMedicos',
  [string]$Database = 'gate213_test',
  [string]$HostName = '127.0.0.1',
  [int]$Port = 54322
)
$ErrorActionPreference = 'Stop'
if ($HostName -notin @('127.0.0.1', 'localhost', '::1')) { throw 'BLOQUEADO: host remoto nao permitido.' }
if ($Database -ne 'gate213_test') { throw 'BLOQUEADO: somente o DB local descartavel gate213_test.' }
if (-not (Test-Path -LiteralPath $Workspace -PathType Container)) { throw "Workspace nao encontrado: $Workspace" }
$files = @(Get-ChildItem -LiteralPath (Join-Path $Workspace 'supabase\migrations') -File -Filter '*.sql' | Where-Object { $_.Name -match '^\d{14}_.*\.sql$' } | Sort-Object Name)
Write-Host "Migrations locais na raiz: $($files.Count)"
$files | ForEach-Object { Write-Host ('  ' + $_.Name) }
if ($files.Count -ne 14) { throw 'Inventario divergente: esperado 14 migrations ativas. Nenhum banco foi modificado.' }
if (-not (Get-Command psql -ErrorAction SilentlyContinue)) { throw 'psql nao disponivel no PATH. Nenhum banco foi modificado.' }
$env:PGHOST = $HostName
$env:PGPORT = "$Port"
$env:PGDATABASE = $Database
# Explicitly set a local, read-only session. Does not create/drop databases, tables, users or migrations.
$env:PGOPTIONS = '-c default_transaction_read_only=on -c statement_timeout=12000'
$scriptPath = Join-Path $PSScriptRoot 'validate_gate24.sql'
& psql -X -v ON_ERROR_STOP=1 -f $scriptPath
if ($LASTEXITCODE -ne 0) { throw "psql falhou com exit code $LASTEXITCODE" }
Write-Host 'Auditoria de schema executada. Verifique FAIL/REVIEW antes de qualquer GO.'
